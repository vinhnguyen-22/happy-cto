# Tea Realms CTO – New interactive asset pack

Includes 13 transparent PNG assets for six wish markers, the central tea ceremony set, a wish plaque, a tea-leaf cursor, and four atmospheric particles.

## Paths
- `assets/markers/` – six `48x48` wish markers for the six realms.
- `assets/02_Tea_Temple_Hub/tea_ceremony_set.png` – `128x128` tray with teapot and cups.
- `assets/ui/item_wish_tag_gold.png` – `48x48` wish plaque.
- `assets/ui/cursor_tea_leaf.png` – `32x32` cursor (requested hotspot 0,0).
- `assets/particles/` – four `16x16` particles.

All PNGs use RGBA with transparent background. Generated assets have been extracted from concept sheets and downsampled. Inspect at actual rendered size in your game before final deployment. No GIF animation is included.
